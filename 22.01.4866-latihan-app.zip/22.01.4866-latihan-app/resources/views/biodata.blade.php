@extends('layouts.app')
<h2>Tambahkan Biodata Anda</h2>
@section('title', 'Biodata Karyawan')
@section('sidebar')
@parent
<p>This is appended to the master sidebar.</p>
@endsection
@section('content')
<table>...
</table>
@endsection